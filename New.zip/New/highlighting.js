// Word lists
const isdWords = {
    "A": ["Dhanmondi", "Motijheel", "Demra", "Bandar", "Siddhirganj", "Mohammadpur", "Badda"],
    "B": ["Uttara", "Narayanganj", "Malibagh", "Bashabo"],
    "C": ["Shewrapara", "Sonargaon", "Gazaria", "Mirpur-1", "Rayerbag", "Banani"],
    "D": ["Farmgate", "Pallabi", "Lalbag", "Diabari", "Hazaribagh", "Bashundhara"]
};

const osdWords = {
    "1": ["Khagrachori-Matiranga","Chittagong-Bayezid", "Chittagong-Fatikchori", "Chittagong-Halishahar", "Chittagong-Hathazari", "Chittagong-Lichubagan", "Chittagong-Mirshorai", "Chittagong-Nasirabad", "Chittagong-Potenga", "Chittagong-Rangunia", "Chittagong-Shitakundo", "Cumilla-Daudkandi", "Chittagong-Raozan", "Khagrachori-Guimara", "Khagrachari", "Khagrachori-Dighinala", "Rangamati"],
    "2": ["Chittagong-Bashkhali", "Chittagong-Keranirhat", "Chittagong-Potiya", "Chittagong-Sandwip", "Cox's Bazar", "Cox's Bazar-Chokoria", "Cox's Bazar-Kutubdia", "Cox's Bazar-Ramu", "Cox's Bazar-Ukhia", "Coxsbazar-Moheshkhali", "Coxsbazar-Teknaf", "Bandarban", "Chittagong-Anwara"],
    "3": ["Cumilla Nangolkot", "Cumilla-Laksam", "Noakhali-Subarnachar", "Noakhali-Sonapur", "Noakhali", "Laksam"],
    "4": ["Chandpur-Shahrasti", "Feni-Sonagazi", "Lakshmipur", "Chandpur", "Chandpur-Faridgonj", "Chandpur-Haziganj", "Chandpur-Matlab", "Chandpur Kachua", "Char-Alexzander", "Comilla-Barura", "Cumilla", "Cumilla-Chandina", "Cumilla-Chauddagram", "Cumilla-Homna", "Cumilla-Laksam", "Cumilla-Meghna", "Cumilla-Muradnagar", "Feni", "Feni-Chhagalnaiya", "Lakshmipur-Ramgonj", "Noakhali-Bashurhat", "Noakhali-Hatiya", "Noakhali-Sonaimuri", "Cumilla - B.para"],
    "6": ["Moulvibazar-Rajnagar", "B.Baria", "B.Baria-Kasba", "B.Baria-Nabinagar", "B.Baria-Sarail", "Habiganj", "Habiganj-Madhobpur", "Habiganj-Shaistaganj", "Kishoreganj", "Kishoreganj-Bajitpur", "Kishoreganj-Bhairab", "Kishoreganj-Mithamoin", "Moulovibazar-Kulaura", "Moulvibazar", "Moulvibazar-Sreemangal", "B.baria-Nasirnagar", "Narsingdi-Raipura", "B.Baria-Bijaynagar", "Habiganj-Azmiriganj"],
    "7": ["Habiganj-Nabigonj", "Sunamganj", "Sunamganj-Bishwabvarpur", "Sunamganj-Chhatak", "Sunamganj-Derai", "Sylhet", "Sylhet-Beanibazar", "Sylhet-Golapganj", "Sylhet-Jagannathpur", "Sylhet-Jaintapur", "Sylhet-South Surma", "Sylhet-Zakiganj", "Sylhet-Kanaighat", "Sylhet-Osmaninagar", "Sylhet-Companiganj"],
    "8": ["Patuakhali-Kuakata", "Patuakhali-Bauphal", "Jhalokathi-Rajapur", "Barguna-Patharghata", "Bhola-Borhanuddin", "Barishal-Muladi", "Barguna", "Barguna-Amtali", "Barishal", "Barishal-Bakergonj", "Barishal-Banaripara", "Barishal-Gouranodi", "Barishal-MulACi", "Barishal-Wazirpur", "Bhola", "Bhola-Charfashion", "Bhola-Lalmohon", "Jhalokathi", "Patuakhali", "Patuakhali-Galachipa", "Patuakhali-Kalapara", "Pirojpur", "Pirojpur-Mathbaria"],
    "10": ["Kushtia-Kumarkhali", "Faridpur-Nagarkanda", "Gopalganj-Kashiani", "Khulna-Dumuria", "Gopalganj", "Gopalganj-Muksudpur", "Khulna", "Khulna-Daulatpur", "Khulna-Paikgacha", "Shariatpur", "Shariatpur-Damudya", "Madaripur", "Madaripur-Takerhat", "Bagerhat-Fakirhat", "Bhanga", "Faridpur", "Faridpur-Boalmari", "Kushtia", "Kushtia-Bheramara", "Rajbari-Pangsha", "Rajbari"],
    "11": ["Bagerhat-Morrelganj", "Bagerhat", "Bagerhat-Mongla", "Jashore-Monirampur", "Jashore", "Jashore-Benapol", "Jashore-Noapara", "Narail", "Satkhira", "Satkhira-Shyamnagar", "Chuadanga", "Chuadanga-Darshana", "Jhenaidha-Kotchadpur", "Jhenidah", "Magura", "Meherpur", "Faridpur-Madhukhali", "Jhenaidha-Kotchadpur"],
    "12": ["Chapai- Kansat", "Chapainawabganj", "Natore", "Natore-Bonpara", "Rajshahi", "Rajshahi-Baneshwar", "Rajshahi-Mohonpur"],
    "13": ["Pabna", "Pabna-Bhangura", "Pabna-Ishwardi", "Shahjadpur-Bera", "Sirajganj", "Ullapara-Tarash", "Bogra", "Bogra-Majhira"],
    "14": ["Dinajpur-Birganj", "Chapai-Rohonpur", "Dinajpur", "Dinajpur-Birampur", "Joypurhat", "Naogaon", "Naogaon-Nazipur", "Naogaon-Manda"],
    "15": ["Gaibandha", "Gaibandha-Gobindaganj", "Kurigram", "Kurigram-Nageshwari", "Kurigram-Rowmari", "Lalmonirhat", "Lalmonirhat-Patgram", "Mokamtola", "Nilphamari", "Nilphamari-Domar", "Panchagarh", "Rangpur", "Rangpur-Pirgonj", "Saidpur", "Thakurgaon", "Thakurgaon-Ranisankail"],
    "16": ["Manikganj-Singair", "Tangail Nagarpur", "Tangail Nagarpur", "Narsingdi-Panchdona", "Araihazar-Narayanganj", "Bhulta - Gawsia", "Narsingdi", "Narsingdi- Monohardi", "Rupganj - Neela Market", "Manikganj", "Manikganj-Ghior", "Savar", "Savar - Amin Bazar", "Savar-Baipail", "Savar-Dhamrai", "Dohar Nowabganj", "Gazipur-Board Bazar", "Gazipur-Joydebpur", "Keranigonj", "Munshiganj-Sreenagar", "Munshiganj-Tongibari", "Munsiganj", "Gazipur-Kaliyakoir", "Gazipur- Kashimpur"],
    "17": ["Jamalpur-Madarganj", "Mymensingh-Gafargaon", "Sherpur-Nalitabari", "Jamalpur", "Jamalpur-Dewanganj-Bakshiganj", "Mawna", "Mymensingh", "Mymensingh-Bhaluka", "Mymensingh-Gouripur", "Mymensingh-Trishal", "Netrokona", "Netrokona-Mohanganj", "Phulpur", "Netrokona-Kalmakanda", "Netrokona-Durgapur", "Sherpur", "Tangail", "Tangail - Mirzapur", "Tangail-Kalihati", "Tangail-Madhupur", "Gazipur-Kaliganj", "Gazipur-Kapasia", "Mymensingh-Dhobaura"]
};

const isdColors = {
    "A": "yellow",
    "B": "yellow",
    "C": "yellow",
    "D": "yellow"
};

// Allow dashes in phrase matching
function escapeRegex(str) {
    return str.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&');
}

// Highlight phrases including hyphenated ones
function highlightWords(wordList, color = "yellow") {
    const uniqueWords = [...new Set(wordList)].sort((a, b) => b.length - a.length);
    const escapedWords = uniqueWords.map(escapeRegex);

    // Strict full match: only highlight complete words or phrases, no partial matches
    const regex = new RegExp(`(?<!\\w)(${escapedWords.join("|")})(?!\\w|-)`, "gi");

    function walk(node) {
        if (node.nodeType === Node.TEXT_NODE) {
            const originalText = node.nodeValue;
            if (regex.test(originalText)) {
                const newHTML = originalText.replace(regex, (match) => {
                    return `<span style="
                        background-color: ${color};
                        color: black;
                        font-weight: bold;
                        font-size: 15px;
                        padding: 2px 5px;
                        border-radius: 4px;
                        box-shadow: 1px 1px 4px rgba(0,0,0,0.3);
                        display: inline-block;
                    ">${match}</span>`;
                });
                const span = document.createElement("span");
                span.innerHTML = newHTML;
                node.replaceWith(span);
            }
        } else if (node.nodeType === Node.ELEMENT_NODE && !["SCRIPT", "STYLE"].includes(node.tagName)) {
            Array.from(node.childNodes).forEach(walk);
        }
    }

    walk(document.body);
}




// Message listener
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "highlightISD" && isdWords[message.line]) {
        const lineWords = isdWords[message.line];
        const exclude = message.exclude || [];
        const filteredWords = lineWords.filter(word => !exclude.includes(word));
        highlightWords(filteredWords, isdColors[message.line]);
    } else if (message.type === "highlightOSD" && osdWords[message.option]) {
        highlightWords(osdWords[message.option]);
    }
});
