// Word lists
const isdWords = {
    "A": ["Dhanmondi", "Motijheel", "Demra", "Bandar", "Siddhirganj", "Mohammadpur"],
    "B": ["Uttara", "Narayanganj"],
    "C": ["Shewrapara", "Sonargaon", "Gazaria", "Mirpur-1", "Rayerbag"],
    "D": ["Pallabi", "Lalbag", "Diabari", "Hazaribagh", "Bashundhara"]
};

const osdWords = {
    "1": ["Chittagong-Bayezid", "Chittagong-Fatikchori", "Chittagong-Halishahar", "Chittagong-Hathazari", 
                  "Chittagong","Lichubagan", "Chittagong","Mirshorai", "Chittagong","Nasirabad", "Chittagong","Potenga", 
                  "Chittagong,Rangunia", "Chittagong,Shitakundo", "Cumilla,Daudkandi", "Chittagong,Raozan", 
                  "Khagrachori","Guimara", "Khagrachari","Dighinala", "Rangamati", "Khagrachori", "Dighinala","Raozan","Cumilla","Daudkandi","Rangunia","Shitakundo"], 
    "2": ["Anwara","Chittagong", "Coxsbazar", "Bandarban", "Bashkhali", "Keranirhat", "Potiya", "Sandwip", "Cox's Bazar", "Chokoria", "Kutubdia", "Ramu", "Ukhia", "Moheshkhali", "Teknaf", "Anwara"],
    "4": ["Bashurhat","Kachua","Feni","Noakhali-Sonapur","B.para","Chandpur", "Faridgonj", "Haziganj", "Matlab", "Kachua", "Char-Alexzander", "Comilla", "Barura", "Cumilla", "Chandina", "Chauddagram", "Homna", "Laksam", "Meghna", "Muradnagar", "Feni", "Chhagalnaiya", "Lakshmipur", "Ramgonj", "Noakhali", "Bashurhat", "Hatiya", "Sonaimuri", "Sonapur"],
    "6": ["Rajnagar","Kishoreganj","Nabigonj","Moulovibazar","Azmiriganj","B.Baria", "Kasba","Kishoreganj","Bajitpur","Mithamoin","Moulvibazar","B.Baria", "Nabinagar", "Sarail", "Nasirnagar", "Bijaynagar", "Habiganj", "Madhobpur", "Shaistaganj", "Kishoreganj", "Bajitpur", "Bhairab", "Mithamoin", "Moulvibazar", "Kulaura", "Sreemangal", "Narsingdi", "Raipura"],
    "7": ["Kanaighat","Osmaninagar","Companiganj","Osmaninagar","Sunamganj","Sunamganj","Habiganj", "Nabigonj", "Sunamganj", "Bishwabvarpur", "Chhatak", "Derai", "Sylhet", "Beanibazar", "Golapganj", "Jagannathpur", "Jaintapur", "South Surma", "Zakiganj"],
    "8": ["Gouranodi","Barishal", "Muladi", "Bakergonj", "Banaripara", "Gouranodi", "Wazirpur", "Bagerhat", "Morrelganj", "Barguna", "Amtali", "Bhola", "Charfashion", "Lalmohon", "Jhalokathi", "Patuakhali", "Galachipa", "Kalapara", "Pirojpur", "Mathbaria"],
    "10": ["Khulna-Dumuria","Pangsha","Gopalganj", "Muksudpur", "Khulna", "Daulatpur", "Paikgacha", "Shariatpur", "Damudya", "Madaripur", "Takerhat", "Bagerhat-Fakirhat", "Bhanga", "Faridpur", "Boalmari", "Kushtia", "Bheramara", "Rajbari"],
    "11": ["Jhenaidha","Jashore", "Jhenidah", "Faridpur-Madhukhali", "Benapol", "Noapara", "Narail", "Satkhira", "Shyamnagar", "Chuadanga", "Darshana", "Jhenaidah", "Kotchadpur", "Magura", "Meherpur"],
    "12": ["Chapainawabganj", "Natore", "Bonpara", "Rajshahi", "Baneshwar", "Mohonpur"],
    "13": ["Pabna", "Bhangura", "Ishwardi", "Shahjadpur", "Bera", "Sirajganj", "Ullapara", "Tarash", "Bogra", "Majhira"],
    "14": ["Nazipur","Birganj","Chapai", "Rohonpur", "Dinajpur", "Birampur", "Joypurhat", "Naogaon", "Nazipur", "Manda"],
    "15": ["Gaibandha", "Gobindaganj", "Kurigram", "Nageshwari", "Rowmari", "Lalmonirhat", "Patgram", "Mokamtola", "Nilphamari", "Domar", "Panchagarh", "Rangpur", "Pirgonj", "Saidpur", "Thakurgaon", "Ranisankail"],
    "16": ["Araihazar", "Kashimpur", "Narayanganj", "Bhulta", "Gawsia", "Narsingdi", "Monohardi", "Rupganj", "Neela Market", "Manikganj", "Ghior", "Savar", "Amin Bazar", "Baipail", "Dhamrai", "Dohar", "Nowabganj", "Gazipur", "Board Bazar", "Joydebpur", "Keranigonj", "Munshiganj", "Sreenagar", "Tongibari", "Kaliyakoir", "Munsiganj"],
    "17": ["Jamalpur", "Dewanganj", "Dhobaura", "Bakshiganj", "Mawna", "Mymensingh", "Bhaluka", "Gouripur", "Trishal", "Netrokona", "Mohanganj", "Phulpur", "Kalmakanda", "Durgapur", "Sherpur", "Tangail", "Mirzapur", "Kalihati", "Madhupur", "Kaliganj", "Kapasia", "Munsiganj", "Gazipur"]
};

const isdColors = {
    "A": "yellow",
    "B": "yellow",
    "C": "yellow",
    "D": "yellow"
};

// Main highlighter
function highlightWords(wordList, color = "yellow") {
    const regex = new RegExp(`\\b(${wordList.join("|")})\\b`, "gi");

    function walk(node) {
        if (node.nodeType === Node.TEXT_NODE) {
            const matches = node.nodeValue.match(regex);
            if (matches) {
                const span = document.createElement("span");
                span.innerHTML = node.nodeValue.replace(regex, match =>
                    `<span style="background-color:${color}; color:black; font-weight: bold;">${match}</span>`
                );
                node.replaceWith(span);
            }
        } else if (node.nodeType === Node.ELEMENT_NODE && !["SCRIPT", "STYLE"].includes(node.tagName)) {
            Array.from(node.childNodes).forEach(walk);
        }
    }

    walk(document.body);
}

// Listen for popup messages
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "highlightISD" && isdWords[message.line]) {
        highlightWords(isdWords[message.line], isdColors[message.line]);
    } else if (message.type === "highlightOSD" && osdWords[message.option]) {
        highlightWords(osdWords[message.option]);
    }
});