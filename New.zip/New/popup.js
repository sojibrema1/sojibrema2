document.addEventListener('DOMContentLoaded', () => {
  setupISDHandlers();
  setupOSDInput();

  autoCheckForUpdate(); // Check for update on popup open

  document.getElementById("checkUpdate").addEventListener("click", () => {
    checkForUpdate({ autoDownload: true }); // Manually triggered with auto-download
  });
});

function setupISDHandlers() {
  ["A", "B", "C", "D"].forEach(line => {
    document.getElementById("line" + line).addEventListener("click", () => {
      sendMessageToTab({ type: "highlightISD", line });
    });
  });
}

function setupOSDInput() {
  const osdInput = document.getElementById("osdInput");
  let osdTimer;

  osdInput.addEventListener("input", (e) => {
    clearTimeout(osdTimer);
    const value = e.target.value.trim();
    if (value) {
      osdTimer = setTimeout(() => {
        sendMessageToTab({ type: "highlightOSD", option: value });
        osdInput.value = "";
      }, 500);
    }
  });

  osdInput.focus();
}

// 📦 Auto check for updates when popup opens
function autoCheckForUpdate() {
  checkForUpdate({ autoDownload: false }); // Just prompt user
}

// 🔍 General check function
async function checkForUpdate({ autoDownload }) {
  const statusEl = document.getElementById("updateStatus");
  statusEl.textContent = "Checking for update...";

  try {
    const response = await fetch("https://raw.githubusercontent.com/sojibrema1/sojibrema2/main/version.txt");
    const remoteVersion = (await response.text()).trim();
    const currentVersion = chrome.runtime.getManifest().version;

    if (remoteVersion !== currentVersion) {
      if (autoDownload) {
        statusEl.innerHTML = `Update ${remoteVersion} found.<br>Downloading...`;
        downloadUpdate();
      } else {
        if (confirm(`Update ${remoteVersion} available. Download now?`)) {
          downloadUpdate();
          statusEl.textContent = `Downloading version ${remoteVersion}...`;
        } else {
          statusEl.textContent = `Update ${remoteVersion} available.`;
        }
      }
    } else {
      statusEl.textContent = "You are using the latest version.";
    }
  } catch (err) {
    statusEl.textContent = "Failed to check for update.";
  }
}

// 📥 Download update ZIP
function downloadUpdate() {
  const downloadUrl = "https://github.com/sojibrema1/sojibrema2/raw/main/New.zip";
  const link = document.createElement("a");
  link.href = downloadUrl;
  link.download = "extension-update.zip";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// 🚀 Send message to content script
function sendMessageToTab(message) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, message);
    }
  });
}
