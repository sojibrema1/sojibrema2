function sendMessageToTab(message) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, message);
    }
  });
}

document.getElementById("lineA").addEventListener("click", () => {
  sendMessageToTab({ type: "highlightISD", line: "A" });
});

document.getElementById("lineB").addEventListener("click", () => {
  sendMessageToTab({ type: "highlightISD", line: "B" });
});

document.getElementById("lineC").addEventListener("click", () => {
  sendMessageToTab({ type: "highlightISD", line: "C" });
});

document.getElementById("lineD").addEventListener("click", () => {
  sendMessageToTab({ type: "highlightISD", line: "D" });
});

document.getElementById("osdInput").addEventListener("input", (e) => {
  const value = e.target.value;
  if (value) {
    sendMessageToTab({ type: "highlightOSD", option: value });
  }
});

// Automatically focus OSD input on popup open
document.getElementById("osdInput").focus();
