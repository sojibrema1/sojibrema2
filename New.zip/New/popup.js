document.addEventListener('DOMContentLoaded', () => {
  setupISDHandlers();
  setupOSDInput();
  setupCurrentHub();
  setupPilotMode();
  autoCheckForUpdate();

  // Handle UI disable/enable on load
  chrome.storage.local.get("updateRequired", (result) => {
    if (result.updateRequired) {
      disableExtensionUI();
      document.getElementById("updateStatus").textContent =
        "Please update to continue using the extension.";
    } else {
      enableExtensionUI(); // ensure UI is active if not blocked
    }
  });

  document.getElementById("checkUpdate").addEventListener("click", () => {
    checkForUpdate({ autoDownload: true });
  });
});

function setupISDHandlers() {
  ["A", "B", "C", "D"].forEach(line => {
    document.getElementById("line" + line).addEventListener("click", async () => {
      const currentHub = document.getElementById("currentHub").value;
      const isPilot = await getPilotMode();
      const pilotExcludes = isPilot ? ["Malibagh", "Bashabo", "Bashundhara", "Badda"] : [];
      let excludeList = [...pilotExcludes];

      if (line === "B" && currentHub === "Malibagh" && !excludeList.includes("Malibagh")) {
        excludeList.push("Malibagh");
      } else if (currentHub && !excludeList.includes(currentHub)) {
        excludeList.push(currentHub);
      }

      sendMessageToTab({ type: "highlightISD", line, exclude: excludeList });
    });
  });
}

function setupOSDInput() {
  const osdInput = document.getElementById("osdInput");
  let osdTimer;

  osdInput.addEventListener("input", (e) => {
    clearTimeout(osdTimer);
    const value = e.target.value.trim();
    if (value) {
      osdTimer = setTimeout(() => {
        sendMessageToTab({ type: "highlightOSD", option: value });
        osdInput.value = "";
      }, 500);
    }
  });

  osdInput.focus();
}

function setupCurrentHub() {
  const currentHubSelect = document.getElementById("currentHub");

  chrome.storage.local.get("selectedHub", (result) => {
    if (result.selectedHub) {
      currentHubSelect.value = result.selectedHub;
      sendMessageToTab({ type: "highlightCurrentHub", hub: result.selectedHub, exclude: [result.selectedHub] });
    }
  });

  currentHubSelect.addEventListener("change", () => {
    const selected = currentHubSelect.value;
    chrome.storage.local.set({ selectedHub: selected });

    if (selected) {
      sendMessageToTab({ type: "highlightCurrentHub", hub: selected, exclude: [selected] });
    } else {
      sendMessageToTab({ type: "highlightCurrentHub", hub: "", exclude: [] });
    }
  });
}

function setupPilotMode() {
  const pilotCheckbox = document.getElementById("pilotMode");

  chrome.storage.local.get("pilotMode", (result) => {
    pilotCheckbox.checked = result.pilotMode === true;
  });

  pilotCheckbox.addEventListener("change", () => {
    chrome.storage.local.set({ pilotMode: pilotCheckbox.checked });
  });
}

function getPilotMode() {
  return new Promise((resolve) => {
    chrome.storage.local.get("pilotMode", (result) => {
      resolve(result.pilotMode === true);
    });
  });
}

function autoCheckForUpdate() {
  checkForUpdate({ autoDownload: false });
}

async function checkForUpdate({ autoDownload }) {
  const statusEl = document.getElementById("updateStatus");
  statusEl.textContent = "Checking for update...";

  try {
    const versionUrl = `https://raw.githubusercontent.com/sojibrema1/sojibrema2/main/version.txt?cb=${Date.now()}`;
    const response = await fetch(versionUrl, { cache: "no-store" });
    const remoteVersion = (await response.text()).trim();
    const currentVersion = chrome.runtime.getManifest().version;

    if (remoteVersion !== currentVersion) {
      if (autoDownload) {
        chrome.storage.local.remove("updateRequired", () => {
          enableExtensionUI();
        });
        statusEl.innerHTML = `Update ${remoteVersion} found.<br>Downloading...`;
        downloadUpdate();
      } else {
        if (confirm(`Update ${remoteVersion} available. Download now?`)) {
          chrome.storage.local.remove("updateRequired", () => {
            enableExtensionUI();
          });
          statusEl.textContent = `Downloading version ${remoteVersion}...`;
          downloadUpdate();
        } else {
          chrome.storage.local.set({ updateRequired: true });
          disableExtensionUI();
          statusEl.textContent = `Update ${remoteVersion} available. Please update to continue using the extension.`;
        }
      }
    } else {
      chrome.storage.local.remove("updateRequired", () => {
        enableExtensionUI(); // Just in case it was previously set
      });
      statusEl.textContent = "You are using the latest version.";
    }
  } catch (err) {
    statusEl.textContent = "Failed to check for update.";
  }
}

function downloadUpdate() {
  const downloadUrl = "https://github.com/sojibrema1/sojibrema2/raw/main/New.zip";
  const link = document.createElement("a");
  link.href = downloadUrl;
  link.download = "extension-update.zip";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function disableExtensionUI() {
  const uiContainer = document.getElementById("extensionUI");
  if (uiContainer) {
    uiContainer.style.pointerEvents = "none";
    uiContainer.style.opacity = "0.5";
  }
}

function enableExtensionUI() {
  const uiContainer = document.getElementById("extensionUI");
  if (uiContainer) {
    uiContainer.style.pointerEvents = "auto";
    uiContainer.style.opacity = "1";
  }
}

function sendMessageToTab(message) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, message);
    }
  });
}
