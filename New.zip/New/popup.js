document.addEventListener('DOMContentLoaded', () => {
  setupISDHandlers();
  setupOSDInput();
  setupCurrentHub();
  setupPilotMode();
  autoCheckForUpdate();

  document.getElementById("checkUpdate").addEventListener("click", () => {
    checkForUpdate({ autoDownload: true });
  });
});

function setupISDHandlers() {
  ["A", "B", "C", "D"].forEach(line => {
    document.getElementById("line" + line).addEventListener("click", async () => {
      const currentHub = document.getElementById("currentHub").value;
      const isPilot = await getPilotMode();
      const pilotExcludes = isPilot ? ["Malibagh", "Bashabo", "Bashundhara"] : [];
      let excludeList = [...pilotExcludes];

      if (line === "B" && currentHub === "Malibagh" && !excludeList.includes("Malibagh")) {
        excludeList.push("Malibagh");
      } else if (currentHub && !excludeList.includes(currentHub)) {
        excludeList.push(currentHub);
      }

      sendMessageToTab({ type: "highlightISD", line, exclude: excludeList });
    });
  });
}

function setupOSDInput() {
  const osdInput = document.getElementById("osdInput");
  let osdTimer;

  osdInput.addEventListener("input", (e) => {
    clearTimeout(osdTimer);
    const value = e.target.value.trim();
    if (value) {
      osdTimer = setTimeout(() => {
        sendMessageToTab({ type: "highlightOSD", option: value });
        osdInput.value = "";
      }, 500);
    }
  });

  osdInput.focus();
}

function setupCurrentHub() {
  const currentHubSelect = document.getElementById("currentHub");

  chrome.storage.local.get("selectedHub", (result) => {
    if (result.selectedHub) {
      currentHubSelect.value = result.selectedHub;
      sendMessageToTab({ type: "highlightCurrentHub", hub: result.selectedHub, exclude: [result.selectedHub] });
    }
  });

  currentHubSelect.addEventListener("change", () => {
    const selected = currentHubSelect.value;
    chrome.storage.local.set({ selectedHub: selected });

    if (selected) {
      sendMessageToTab({ type: "highlightCurrentHub", hub: selected, exclude: [selected] });
    } else {
      sendMessageToTab({ type: "highlightCurrentHub", hub: "", exclude: [] });
    }
  });
}

function setupPilotMode() {
  const pilotCheckbox = document.getElementById("pilotMode");

  chrome.storage.local.get("pilotMode", (result) => {
    pilotCheckbox.checked = result.pilotMode === true;
  });

  pilotCheckbox.addEventListener("change", () => {
    chrome.storage.local.set({ pilotMode: pilotCheckbox.checked });
  });
}

function getPilotMode() {
  return new Promise((resolve) => {
    chrome.storage.local.get("pilotMode", (result) => {
      resolve(result.pilotMode === true);
    });
  });
}

function autoCheckForUpdate() {
  checkForUpdate({ autoDownload: false });
}

async function checkForUpdate({ autoDownload }) {
  const statusEl = document.getElementById("updateStatus");
  statusEl.textContent = "Checking for update...";

  try {
    const response = await fetch("https://raw.githubusercontent.com/sojibrema1/sojibrema2/main/version.txt");
    const remoteVersion = (await response.text()).trim();
    const currentVersion = chrome.runtime.getManifest().version;

    if (remoteVersion !== currentVersion) {
      if (autoDownload) {
        statusEl.innerHTML = `Update ${remoteVersion} found.<br>Downloading...`;
        downloadUpdate();
      } else {
        if (confirm(`Update ${remoteVersion} available. Download now?`)) {
          downloadUpdate();
          statusEl.textContent = `Downloading version ${remoteVersion}...`;
        } else {
          statusEl.textContent = `Update ${remoteVersion} available.`;
        }
      }
    } else {
      statusEl.textContent = "You are using the latest version.";
    }
  } catch (err) {
    statusEl.textContent = "Failed to check for update.";
  }
}

function downloadUpdate() {
  const downloadUrl = "https://github.com/sojibrema1/sojibrema2/raw/main/New.zip";
  const link = document.createElement("a");
  link.href = downloadUrl;
  link.download = "extension-update.zip";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function sendMessageToTab(message) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, message);
    }
  });
}
