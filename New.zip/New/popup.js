document.addEventListener('DOMContentLoaded', () => {
  setupISDHandlers();
  setupOSDInput();
  setupCurrentHub();
  autoCheckForUpdate();

  document.getElementById("checkUpdate").addEventListener("click", () => {
    checkForUpdate({ autoDownload: true });
  });
});

function setupISDHandlers() {
  ["A", "B", "C", "D"].forEach(line => {
    document.getElementById("line" + line).addEventListener("click", () => {
      const currentHub = document.getElementById("currentHub").value;
      // Exclude selected hub if line B or selected hub is in the exclude list
      if (line === "B" && currentHub === "Malibagh") {
        sendMessageToTab({ type: "highlightISD", line, exclude: ["Malibagh"] });
      } else if (currentHub) {
        // Exclude the selected hub from highlighting for any line
        sendMessageToTab({ type: "highlightISD", line, exclude: [currentHub] });
      } else {
        sendMessageToTab({ type: "highlightISD", line });
      }
    });
  });
}

function setupOSDInput() {
  const osdInput = document.getElementById("osdInput");
  let osdTimer;

  osdInput.addEventListener("input", (e) => {
    clearTimeout(osdTimer);
    const value = e.target.value.trim();
    if (value) {
      osdTimer = setTimeout(() => {
        sendMessageToTab({ type: "highlightOSD", option: value });
        osdInput.value = "";
      }, 500);
    }
  });

  osdInput.focus();
}

function setupCurrentHub() {
  const currentHubSelect = document.getElementById("currentHub");

  // Restore saved hub selection and highlight
  chrome.storage.local.get("selectedHub", (result) => {
    if (result.selectedHub) {
      currentHubSelect.value = result.selectedHub;
      // Send highlight request excluding the selected hub
      sendMessageToTab({ type: "highlightCurrentHub", hub: result.selectedHub, exclude: [result.selectedHub] });
    }
  });

  // Save selection and send message excluding selected hub
  currentHubSelect.addEventListener("change", () => {
    const selected = currentHubSelect.value;
    chrome.storage.local.set({ selectedHub: selected });

    if (selected) {
      sendMessageToTab({ type: "highlightCurrentHub", hub: selected, exclude: [selected] });
    } else {
      sendMessageToTab({ type: "highlightCurrentHub", hub: "", exclude: [] });
    }
  });
}

function autoCheckForUpdate() {
  checkForUpdate({ autoDownload: false });
}

async function checkForUpdate({ autoDownload }) {
  const statusEl = document.getElementById("updateStatus");
  statusEl.textContent = "Checking for update...";

  try {
    const response = await fetch("https://raw.githubusercontent.com/sojibrema1/sojibrema2/main/version.txt");
    const remoteVersion = (await response.text()).trim();
    const currentVersion = chrome.runtime.getManifest().version;

    if (remoteVersion !== currentVersion) {
      if (autoDownload) {
        statusEl.innerHTML = `Update ${remoteVersion} found.<br>Downloading...`;
        downloadUpdate();
      } else {
        if (confirm(`Update ${remoteVersion} available. Download now?`)) {
          downloadUpdate();
          statusEl.textContent = `Downloading version ${remoteVersion}...`;
        } else {
          statusEl.textContent = `Update ${remoteVersion} available.`;
        }
      }
    } else {
      statusEl.textContent = "You are using the latest version.";
    }
  } catch (err) {
    statusEl.textContent = "Failed to check for update.";
  }
}

function downloadUpdate() {
  const downloadUrl = "https://github.com/sojibrema1/sojibrema2/raw/main/New.zip";
  const link = document.createElement("a");
  link.href = downloadUrl;
  link.download = "extension-update.zip";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function sendMessageToTab(message) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, message);
    }
  });
}
