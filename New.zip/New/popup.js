document.addEventListener('DOMContentLoaded', () => {
  // Highlight ISD logic
  document.getElementById("lineA").addEventListener("click", () => {
    sendMessageToTab({ type: "highlightISD", line: "A" });
  });

  document.getElementById("lineB").addEventListener("click", () => {
    sendMessageToTab({ type: "highlightISD", line: "B" });
  });

  document.getElementById("lineC").addEventListener("click", () => {
    sendMessageToTab({ type: "highlightISD", line: "C" });
  });

  document.getElementById("lineD").addEventListener("click", () => {
    sendMessageToTab({ type: "highlightISD", line: "D" });
  });

  // Highlight OSD logic
  document.getElementById("osdInput").addEventListener("input", (e) => {
    const value = e.target.value;
    if (value) {
      sendMessageToTab({ type: "highlightOSD", option: value });
    }
  });

  // Automatically focus OSD input on popup open
  document.getElementById("osdInput").focus();

  // Check for update button functionality
  document.getElementById("checkUpdate").addEventListener("click", async () => {
    const statusEl = document.getElementById("updateStatus");
    statusEl.textContent = "Checking for update...";

    try {
      // Fetch the remote version from GitHub
      const response = await fetch("https://raw.githubusercontent.com/sojibrema1/sojibrema2/main/version.txt");
      const remoteVersion = (await response.text()).trim();

      const currentVersion = chrome.runtime.getManifest().version;

      if (remoteVersion !== currentVersion) {
        statusEl.innerHTML = `New version ${remoteVersion} available!<br> Downloading now...`;

        // Automatically download the ZIP file
        const downloadUrl = "https://github.com/sojibrema1/sojibrema2/raw/main/New.zip";
        
        // Create a temporary download link to trigger the download
        const link = document.createElement("a");
        link.href = downloadUrl;
        link.download = "extension-update.zip"; // Set a default file name
        link.click();  // Automatically triggers the download

      } else {
        statusEl.textContent = "You are using the latest version.";
      }
    } catch (err) {
      statusEl.textContent = "Failed to check for update.";
    }
  });
});

// Send message to the active tab
function sendMessageToTab(message) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, message);
    }
  });
}
